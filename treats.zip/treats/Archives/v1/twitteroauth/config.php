<?php

/**
 * @file
 * A single location to store configuration.
 */

define('CONSUMER_KEY', 'e2o8TLx1BUFZr1YXBwWwIm7bm');
define('CONSUMER_SECRET', 'xDqxfyOM2ZST17QSdsrEbSPOT2dS43gc2Yl9d1x1uIFn256yS5');
define('OAUTH_CALLBACK', 'http://localhost/~thomas/Others/www.blacksuncreative.com/treats/twitteroauth/callback.php');
define('OAUTH_ACCESS_TOKEN', '428577233-BjR7qsZUdS0Ru3RIBR0l4K2zyjf8FolBaN9Yl8Hh');
define('OAUTH_ACCESS_TOKEN_SECRET', 'ZvFexNly9fjfGMZgMb1oVCv29hk5KoQUzBZ9xrIRaXWcQ');

?>
